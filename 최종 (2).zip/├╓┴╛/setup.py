
from distutils.core import setup, Extension
setup(name='test',
version='1.0',
py_modules=['pyScrProject03', 'mysmtplib'],
)

