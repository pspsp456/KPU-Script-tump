import sys
from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import uic
from PyQt5 import QtCore
from PyQt5.QtCore import pyqtSlot

from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, HTTPServer
from xml.etree import ElementTree

#global
conn = None
tree = None
server = "apis.data.go.kr"

class Form(QtWidgets.QDialog):
    
    
    def __init__(self, parent=None):
        QtWidgets.QDialog.__init__(self, parent)
        self.ui = uic.loadUi("ScrProject03.ui", self)
        self.ui.show()
 
    @pyqtSlot()
    def ShowCountry(self):
        global tree

        stradd = "국가 이름 리스트\n"
        
        itemElements = tree.getiterator("item")
        for item in itemElements:
            strTitle = item.find("countryName")
            #print (strTitle)
            #print(type(strTitle.text))
            if len(strTitle.text) > 0 :
                print("countryName:", strTitle.text)
                stradd = stradd + strTitle.text + '\n'
        self.ui.textBrowser.setText(stradd)      

    def CountryInfo(self, QString):
        global tree
        real = False
        stradd = QString

        itemElements = tree.getiterator("item")
        for item in itemElements:
            strTitle = item.find("countryName")
            if strTitle.text == QString:
                real = True
                strTitle = item.find("basic")
                stradd = stradd + strTitle.text
                self.ui.textBrowser_2.setText(stradd)
                break
        if real == False:   
            self.ui.textBrowser_2.setText(QString + " is not real")
        
            
if __name__ == '__main__':   
    conn = HTTPConnection(server)

    uri = "/1262000/CountryBasicService/getCountryBasicList?ServiceKey=FzCbn1kMa0%2Ft0TRkotzGekvr0P0sEYnTfnXGzlfdnh0MaOIgzjKXN4zpALLpJ%2Fj3bwpyZ6ORRm87bSvlhigIrw%3D%3D&numOfRows=999&pageSize=999&pageNo=1&startPage=FzCbn1kMa0%2Ft0TRkotzGekvr0P0sEYnTfnXGzlfdnh0MaOIgzjKXN4zpALLpJ%2Fj3bwpyZ6ORRm87bSvlhigIrw%3D%3D1"
    conn.request("GET", uri)

    req = conn.getresponse()
    print (req.status)
    if int(req.status) == 200 :
        print("Book data downloading complete!")   
        tree = ElementTree.fromstring(req.read())
    else :
        print ("OpenAPI request has been failed!! please retry")


    app = QtWidgets.QApplication(sys.argv)
    w = Form()
    sys.exit(app.exec())

    


























    
    
